bayesian <- function(client) {
    log$debug("computing bayesian network")

    image.name <- get.option('image.name')
    log$debug("Using image: '{image.name}'")

    client$set.task.image(image.name, task.name="bayesian")
    result <- client$call("baysian")

    return(result)
}