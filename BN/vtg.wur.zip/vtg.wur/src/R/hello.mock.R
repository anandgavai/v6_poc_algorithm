#'
#' Example on how to run the federated GLM using the MockClient.
#'
#
# # # Load package datasets
# data(example1, example2, example3)
#
# data1 <- read.csv("D:\\data\\wur\\iknl_data.csv")
# data2 <- read.csv("D:\\data\\wur\\BNdata_train_EMA.csv")
# data3 <- read.csv("D:\\data\\wur\\BNdata_test_EMA.csv")
#
#
# # # Create a Mock client
# datasets <- list(data1, data2, data3)
# #client <- vtg::MockClient$new(datasets, "vtg.glm")
#
# # # Test the algorithm
# #result <- vtg.wur::dglm(client)
#
# vtg.wur::RPC_baysian(data3)
#
