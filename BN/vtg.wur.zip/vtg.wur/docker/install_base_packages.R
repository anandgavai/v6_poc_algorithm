packages <- c(
    "httr",
    "rjson",
    "dplyr",
    "namespace",
    "devtools"
)

install.packages(packages)

